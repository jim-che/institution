package com.institution.com.dto;

public class ElectiveDto {
}

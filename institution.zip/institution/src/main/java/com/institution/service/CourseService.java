package com.institution.service;

import com.institution.entity.Course;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author chengguo
 * @since 2021-08-20
 */
public interface CourseService extends IService<Course> {

}
